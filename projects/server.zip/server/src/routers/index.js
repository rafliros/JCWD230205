const usersRouter = require('./usersRouter')
const roomsRouter = require('./roomsRouter')

module.exports = {
    usersRouter, roomsRouter
}