const usersController = require('./usersController')

module.exports = {
    usersController
}